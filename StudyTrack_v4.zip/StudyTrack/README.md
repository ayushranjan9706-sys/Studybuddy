# StudyTrack - Expo React Native App

## Features
- **Timer Tab** — Study timer with session saving, daily goals, exam countdown
- **Subjects Tab** — 11th and 12th sub-tabs, add subjects + chapters per class
- **Tests Tab** — Test-wise chapter tracking with countdown
- **Exercise Tab** — Weekly plan with monthly progress
- **Progress Tab** — Study & exercise progress charts

## Changes from v3
1. **Subjects tab has 11th / 12th sub-tabs** — chapters stay separate per class
2. **All tab names are text** — no emojis in the bottom tab bar

---

## HOW TO BUILD APK (Phone only — EAS Build, free)

### Step 1 — Install Expo Go to test (optional but recommended)
Install **Expo Go** from Play Store to preview the app instantly.

### Step 2 — Create an Expo account
Go to https://expo.dev → Sign up (free)

### Step 3 — Install Node.js on your PC
Download from https://nodejs.org → install the LTS version

### Step 4 — Open this project folder on your PC
Extract the ZIP, then open a terminal (Command Prompt or PowerShell) in the folder.

### Step 5 — Install dependencies
```
npm install
```

### Step 6 — Install EAS CLI
```
npm install -g eas-cli
```

### Step 7 — Login to Expo
```
eas login
```
Enter your Expo account email and password.

### Step 8 — Configure EAS build
```
eas build:configure
```
Choose **Android** when asked.

### Step 9 — Build the APK
```
eas build -p android --profile preview
```
This uploads your code to Expo's cloud servers and builds the APK for you.
**You don't need Android Studio or any Android SDK on your PC!**

### Step 10 — Download your APK
After 5-10 minutes, EAS will give you a download link in the terminal.
You can also find it at https://expo.dev → Your project → Builds.

Download the `.apk` file and send it to your Android phone (via WhatsApp, Gmail, etc).
On your phone, tap the APK → Install (allow "Install from unknown sources" if asked).

---

## File Structure
```
StudyTrack/
  App.js                         — Main app, tab navigation
  app.json                       — Expo config
  package.json                   — Dependencies
  babel.config.js
  assets/                        — Put icon.png, splash.png here
  src/
    utils/
      constants.js               — Colors, exercise data, helpers
    components/
      Countdown.js               — Countdown timer component
    screens/
      TimerScreen.js             — Study timer + goals
      SubjectsScreen.js          — 11th/12th subjects + chapters
      TestsScreen.js             — Tests + chapter blocks
      ExerciseScreen.js          — Exercise plan
      ProgressScreen.js          — Progress charts
```

---

## Notes
- All data is in-memory (resets if app is closed). For persistent storage,
  AsyncStorage can be added later.
- The app.json has `"package": "com.studytrack.app"` — change if needed.
- Add your own icon.png (1024x1024) and splash.png in the assets/ folder.
