import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet,
} from "react-native";
import Countdown from "../components/Countdown";
import { BLOCK_TYPES, BLOCK_COLORS, SUB_COLORS, todayKey } from "../utils/constants";

export default function TestsScreen({ tests, setTests }) {
  const [activeTestIdx, setActiveTestIdx] = useState(null);
  const [addingTest, setAddingTest] = useState(false);
  const [newTest, setNewTest] = useState({ name: "", date: "" });
  const [newTestSubj, setNewTestSubj] = useState({ name: "", chapters: "" });

  const addTest = () => {
    if (!newTest.name.trim() || !newTest.date) return;
    setTests((p) => [...p, { ...newTest, id: Date.now(), subjects: [], resetDate: null }]);
    setActiveTestIdx(tests.length);
    setNewTest({ name: "", date: "" });
    setAddingTest(false);
  };

  const addTestSubject = (ti) => {
    if (!newTestSubj.name.trim()) return;
    const chapters = newTestSubj.chapters
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean)
      .map((n) => ({ name: n, blocks: {} }));
    setTests((p) =>
      p.map((t, i) =>
        i === ti ? { ...t, subjects: [...t.subjects, { name: newTestSubj.name, chapters }] } : t
      )
    );
    setNewTestSubj({ name: "", chapters: "" });
  };

  const toggleTestBlock = (ti, si, ci, b) =>
    setTests((p) =>
      p.map((t, i) =>
        i === ti
          ? {
              ...t,
              subjects: t.subjects.map((s, j) =>
                j === si
                  ? { ...s, chapters: s.chapters.map((c, k) => (k === ci ? { ...c, blocks: { ...c.blocks, [b]: !c.blocks[b] } } : c)) }
                  : s
              ),
            }
          : t
      )
    );

  const resetTest = (i) =>
    setTests((p) =>
      p.map((tt, ii) =>
        ii === i
          ? { ...tt, subjects: tt.subjects.map((s) => ({ ...s, chapters: s.chapters.map((c) => ({ ...c, blocks: {} })) })), resetDate: todayKey() }
          : tt
      )
    );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {activeTestIdx !== null && tests[activeTestIdx] && (
        <Countdown
          targetDate={tests[activeTestIdx].date}
          label={tests[activeTestIdx].name.toUpperCase()}
          onEdit={(d) => setTests((p) => p.map((t, i) => (i === activeTestIdx ? { ...t, date: d } : t)))}
        />
      )}

      {/* Test selector */}
      <View style={styles.pillRow}>
        {tests.map((t, i) => (
          <TouchableOpacity
            key={i}
            onPress={() => setActiveTestIdx(i)}
            style={[styles.pill, activeTestIdx === i && { borderColor: "#EA4335", backgroundColor: "#EA433522" }]}
          >
            <Text style={[styles.pillText, activeTestIdx === i && { color: "#EA4335" }]}>{t.name}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={() => setAddingTest(true)} style={styles.pillAdd}>
          <Text style={styles.pillAddText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {/* Add test form */}
      {addingTest && (
        <View style={styles.card}>
          <TextInput
            placeholder="Test name"
            value={newTest.name}
            onChangeText={(v) => setNewTest((p) => ({ ...p, name: v }))}
            placeholderTextColor="#555"
            style={styles.input}
          />
          <TextInput
            placeholder="Date (YYYY-MM-DD)"
            value={newTest.date}
            onChangeText={(v) => setNewTest((p) => ({ ...p, date: v }))}
            placeholderTextColor="#555"
            keyboardType="numeric"
            style={styles.input}
          />
          <View style={styles.row}>
            <TouchableOpacity onPress={addTest} style={[styles.btnPrimary, { flex: 1, backgroundColor: "#EA4335" }]}>
              <Text style={styles.btnPrimaryText}>Create Test</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setAddingTest(false)} style={styles.btnGhost}>
              <Text style={styles.btnGhostText}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Active test detail */}
      {activeTestIdx !== null && tests[activeTestIdx] && (
        <View>
          <View style={styles.card}>
            <Text style={styles.sectionLabel}>+ Subject & Chapters Add Karo</Text>
            <TextInput
              placeholder="Subject name"
              value={newTestSubj.name}
              onChangeText={(v) => setNewTestSubj((p) => ({ ...p, name: v }))}
              placeholderTextColor="#555"
              style={styles.input}
            />
            <TextInput
              placeholder="Chapters (comma se alag karo)"
              value={newTestSubj.chapters}
              onChangeText={(v) => setNewTestSubj((p) => ({ ...p, chapters: v }))}
              placeholderTextColor="#555"
              style={styles.input}
            />
            <TouchableOpacity onPress={() => addTestSubject(activeTestIdx)} style={[styles.btnPrimary, { backgroundColor: "#EA4335" }]}>
              <Text style={[styles.btnPrimaryText, { textAlign: "center" }]}>Add</Text>
            </TouchableOpacity>
          </View>

          {tests[activeTestIdx].subjects.map((subj, si) => {
            const tb = subj.chapters.length * BLOCK_TYPES.length;
            const db = subj.chapters.reduce((a, c) => a + BLOCK_TYPES.filter((b) => c.blocks[b]).length, 0);
            const pct = tb > 0 ? Math.round((db / tb) * 100) : 0;
            return (
              <View key={si} style={styles.card}>
                <View style={styles.rowBetween}>
                  <Text style={[styles.subjName, { color: SUB_COLORS[si % SUB_COLORS.length] }]}>{subj.name}</Text>
                  <Text style={styles.pct}>{pct}%</Text>
                </View>
                <View style={styles.progressBg}>
                  <View style={[styles.progressFill, { width: pct + "%", backgroundColor: SUB_COLORS[si % SUB_COLORS.length] }]} />
                </View>
                {subj.chapters.map((ch, ci) => {
                  const dc = BLOCK_TYPES.filter((b) => ch.blocks[b]).length;
                  return (
                    <View key={ci} style={styles.chapCard}>
                      <View style={styles.rowBetween}>
                        <Text style={styles.chapName}>{ch.name}</Text>
                        <Text style={styles.chapPct}>{dc}/{BLOCK_TYPES.length}</Text>
                      </View>
                      <View style={styles.blockRow}>
                        {BLOCK_TYPES.map((b) => {
                          const done = !!ch.blocks[b];
                          return (
                            <TouchableOpacity
                              key={b}
                              onPress={() => toggleTestBlock(activeTestIdx, si, ci, b)}
                              style={[
                                styles.blockBtn,
                                done && { borderColor: BLOCK_COLORS[b], backgroundColor: BLOCK_COLORS[b] + "33" },
                              ]}
                            >
                              <Text style={[styles.blockBtnText, done && { color: BLOCK_COLORS[b] }]}>
                                {done ? "✓ " : ""}{b}
                              </Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>
                    </View>
                  );
                })}
              </View>
            );
          })}

          {tests[activeTestIdx].subjects.length > 0 && (
            <TouchableOpacity onPress={() => resetTest(activeTestIdx)} style={styles.resetBtn}>
              <Text style={styles.resetBtnText}>Test ke baad reset karo</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {tests.length === 0 && !addingTest && (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>Koi test nahi.</Text>
          <TouchableOpacity onPress={() => setAddingTest(true)} style={[styles.btnPrimary, { backgroundColor: "#EA4335" }]}>
            <Text style={styles.btnPrimaryText}>+ Test Add Karo</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  pillRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 14, alignItems: "center" },
  pill: { paddingHorizontal: 13, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, borderColor: "#2a2a2a" },
  pillText: { color: "#888", fontSize: 13, fontWeight: "600" },
  pillAdd: { paddingHorizontal: 13, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, borderColor: "#333", borderStyle: "dashed" },
  pillAddText: { color: "#555", fontSize: 13 },
  card: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 10, padding: 13, marginBottom: 13 },
  sectionLabel: { fontSize: 11, color: "#888", fontWeight: "600", letterSpacing: 1, marginBottom: 8 },
  input: { backgroundColor: "#111", borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, color: "#fff", padding: 8, fontSize: 13, marginBottom: 8 },
  row: { flexDirection: "row", alignItems: "center", gap: 8 },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 7 },
  btnPrimary: { backgroundColor: "#4285F4", borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  btnPrimaryText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  btnGhost: { borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  btnGhostText: { color: "#aaa", fontSize: 13 },
  progressBg: { backgroundColor: "#252525", borderRadius: 5, height: 5, overflow: "hidden", marginBottom: 10 },
  progressFill: { height: "100%", borderRadius: 5 },
  subjName: { fontWeight: "700", fontSize: 14 },
  pct: { fontSize: 11, color: "#888" },
  chapCard: { backgroundColor: "#141414", borderRadius: 8, padding: 10, marginBottom: 8 },
  chapName: { fontSize: 13, color: "#ccc", fontWeight: "600" },
  chapPct: { fontSize: 11, color: "#666" },
  blockRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 7 },
  blockBtn: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 7, borderWidth: 1.5, borderColor: "#2a2a2a" },
  blockBtnText: { color: "#666", fontSize: 11, fontWeight: "600" },
  resetBtn: { borderWidth: 1, borderColor: "#333", borderRadius: 8, padding: 10, alignItems: "center", marginBottom: 14 },
  resetBtnText: { color: "#EA4335", fontSize: 12 },
  emptyState: { alignItems: "center", marginTop: 50 },
  emptyStateText: { color: "#555", fontSize: 14, marginBottom: 12 },
});
