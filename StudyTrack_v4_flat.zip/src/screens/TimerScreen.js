import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet,
} from "react-native";
import Countdown from "../components/Countdown";
import { todayKey, fmt } from "../utils/constants";

export default function TimerScreen({ subjects, sessions, setSessions }) {
  const [timerSubject, setTimerSubject] = useState("");
  const [timerTopic, setTimerTopic] = useState("");
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [goalMins, setGoalMins] = useState(120);
  const [editGoal, setEditGoal] = useState(false);
  const [goalInput, setGoalInput] = useState("120");
  const [examDate, setExamDate] = useState("2027-05-03");
  const [todayGoals, setTodayGoals] = useState({ date: todayKey(), goals: [] });
  const [newGoalText, setNewGoalText] = useState("");
  const iref = useRef(null);

  useEffect(() => {
    if (todayGoals.date !== todayKey()) setTodayGoals({ date: todayKey(), goals: [] });
  }, []);

  useEffect(() => {
    if (running) iref.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    else clearInterval(iref.current);
    return () => clearInterval(iref.current);
  }, [running]);

  const saveSession = () => {
    if (elapsed < 10) return;
    setSessions((p) => [
      ...p,
      { id: Date.now(), subject: timerSubject || "General", topic: timerTopic || "General", duration: elapsed, date: todayKey() },
    ]);
    setElapsed(0); setRunning(false); setTimerTopic("");
  };

  const todaySecs = sessions.filter((s) => s.date === todayKey()).reduce((a, s) => a + s.duration, 0);
  const goalSecs = goalMins * 60;
  const goalPct = Math.min(100, Math.round((todaySecs / goalSecs) * 100));

  const addGoal = () => {
    if (!newGoalText.trim()) return;
    setTodayGoals((p) => ({ ...p, goals: [...p.goals, { id: Date.now(), text: newGoalText.trim(), done: false }] }));
    setNewGoalText("");
  };
  const toggleGoal = (id) => setTodayGoals((p) => ({ ...p, goals: p.goals.map((g) => g.id === id ? { ...g, done: !g.done } : g) }));
  const deleteGoal = (id) => setTodayGoals((p) => ({ ...p, goals: p.goals.filter((g) => g.id !== id) }));

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Countdown targetDate={examDate} label="EXAM COUNTDOWN" onEdit={setExamDate} />

      {/* Today's Goals */}
      <View style={styles.card}>
        <Text style={styles.sectionLabel}>TODAY'S GOALS</Text>
        <View style={styles.row}>
          <TextInput
            value={newGoalText}
            onChangeText={setNewGoalText}
            onSubmitEditing={addGoal}
            placeholder="Add a goal for today..."
            placeholderTextColor="#555"
            style={[styles.input, { flex: 1, marginBottom: 0, marginRight: 8 }]}
          />
          <TouchableOpacity onPress={addGoal} style={styles.addBtn}>
            <Text style={styles.addBtnText}>+</Text>
          </TouchableOpacity>
        </View>
        {todayGoals.goals.length === 0 && (
          <Text style={styles.emptyText}>Koi goal nahi. Upar add karo!</Text>
        )}
        {todayGoals.goals.map((g) => (
          <View key={g.id} style={styles.goalRow}>
            <TouchableOpacity
              onPress={() => toggleGoal(g.id)}
              style={[styles.checkbox, g.done && styles.checkboxDone]}
            >
              {g.done && <Text style={{ color: "#fff", fontSize: 11 }}>✓</Text>}
            </TouchableOpacity>
            <Text style={[styles.goalText, g.done && styles.goalDone]}>{g.text}</Text>
            <TouchableOpacity onPress={() => deleteGoal(g.id)}>
              <Text style={styles.deleteX}>✕</Text>
            </TouchableOpacity>
          </View>
        ))}
        <Text style={styles.hint}>Auto-resets every 24h</Text>
      </View>

      {/* Daily Study Goal */}
      <View style={styles.card}>
        <View style={styles.rowBetween}>
          <Text style={styles.sectionLabel}>STUDY GOAL</Text>
          {editGoal ? (
            <View style={styles.row}>
              <TextInput
                value={goalInput}
                onChangeText={setGoalInput}
                style={styles.smallInput}
                keyboardType="numeric"
              />
              <Text style={{ color: "#aaa", fontSize: 11, marginHorizontal: 4 }}>min</Text>
              <TouchableOpacity onPress={() => { setGoalMins(Math.max(1, parseInt(goalInput) || 60)); setEditGoal(false); }} style={styles.smallSaveBtn}>
                <Text style={{ color: "#fff", fontSize: 12 }}>OK</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity onPress={() => { setEditGoal(true); setGoalInput(String(goalMins)); }} style={styles.editBtn}>
              <Text style={styles.editBtnText}>{goalMins} min  Edit</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.progressBg}>
          <View style={[styles.progressFill, { width: goalPct + "%", backgroundColor: goalPct >= 100 ? "#34A853" : "#4285F4" }]} />
        </View>
        <View style={styles.rowBetween}>
          <Text style={styles.hint}>{Math.floor(todaySecs / 60)} min studied</Text>
          <Text style={[styles.hint, goalPct >= 100 && { color: "#34A853" }]}>{goalPct}% {goalPct >= 100 ? "Done!" : ""}</Text>
        </View>
      </View>

      {/* Subject picker */}
      {subjects.length > 0 && (
        <View style={{ marginBottom: 11 }}>
          <Text style={[styles.hint, { marginBottom: 7 }]}>SUBJECT</Text>
          <View style={styles.pillRow}>
            {subjects.map((s) => (
              <TouchableOpacity
                key={s.name}
                onPress={() => setTimerSubject(s.name)}
                style={[styles.pill, timerSubject === s.name && { borderColor: s.color, backgroundColor: s.color + "22" }]}
              >
                <Text style={[styles.pillText, timerSubject === s.name && { color: s.color }]}>{s.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      <TextInput
        placeholder="Topic (optional)"
        value={timerTopic}
        onChangeText={setTimerTopic}
        placeholderTextColor="#555"
        style={[styles.input, { marginBottom: 16 }]}
      />

      {/* Timer */}
      <View style={{ alignItems: "center", marginVertical: 18 }}>
        <Text style={[styles.timerDisplay, running && { color: "#4285F4" }]}>{fmt(elapsed)}</Text>
        <Text style={styles.hint}>{running ? `Studying ${timerSubject || "..."}` : elapsed > 0 ? "Paused" : "Ready"}</Text>
      </View>

      <View style={styles.timerControls}>
        <TouchableOpacity onPress={() => { setElapsed(0); setRunning(false); }} style={styles.circleBtn}>
          <Text style={{ color: "#aaa", fontSize: 17 }}>↺</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setRunning((r) => !r)} style={[styles.bigBtn, { backgroundColor: running ? "#EA4335" : "#4285F4" }]}>
          <Text style={{ color: "#fff", fontSize: 24 }}>{running ? "⏸" : "▶"}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={saveSession} disabled={elapsed < 10} style={[styles.circleBtn, elapsed >= 10 && { borderColor: "#34A853", backgroundColor: "#34A85322" }]}>
          <Text style={{ color: elapsed >= 10 ? "#34A853" : "#555", fontSize: 17 }}>✓</Text>
        </TouchableOpacity>
      </View>
      <Text style={[styles.hint, { textAlign: "center", marginTop: 9 }]}>{elapsed >= 10 ? "Tap check to save" : "10 sec minimum"}</Text>
      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  card: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 12, padding: 14, marginBottom: 14 },
  sectionLabel: { fontSize: 11, color: "#888", fontWeight: "600", letterSpacing: 1, marginBottom: 10 },
  row: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  input: { backgroundColor: "#111", borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, color: "#fff", padding: 8, fontSize: 13, marginBottom: 10 },
  addBtn: { backgroundColor: "#4285F4", borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  addBtnText: { color: "#fff", fontSize: 18, fontWeight: "600" },
  goalRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: "#1e1e1e" },
  checkbox: { width: 20, height: 20, borderRadius: 5, borderWidth: 1.5, borderColor: "#333", backgroundColor: "transparent", alignItems: "center", justifyContent: "center" },
  checkboxDone: { borderColor: "#34A853", backgroundColor: "#34A853" },
  goalText: { flex: 1, fontSize: 13, color: "#ddd" },
  goalDone: { color: "#555", textDecorationLine: "line-through" },
  deleteX: { color: "#444", fontSize: 13, padding: 4 },
  hint: { fontSize: 10, color: "#444" },
  progressBg: { backgroundColor: "#252525", borderRadius: 8, height: 6, overflow: "hidden", marginBottom: 5 },
  progressFill: { height: "100%", borderRadius: 8 },
  pillRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  pill: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, borderColor: "#2a2a2a" },
  pillText: { color: "#888", fontSize: 12, fontWeight: "600" },
  timerDisplay: { fontSize: 58, fontWeight: "700", letterSpacing: -2, color: "#fff" },
  timerControls: { flexDirection: "row", gap: 12, justifyContent: "center", alignItems: "center" },
  circleBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#2a2a2a", alignItems: "center", justifyContent: "center" },
  bigBtn: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  editBtn: { borderWidth: 1, borderColor: "#333", borderRadius: 6, paddingHorizontal: 9, paddingVertical: 3 },
  editBtnText: { color: "#aaa", fontSize: 11 },
  smallInput: { backgroundColor: "#252525", borderWidth: 1, borderColor: "#333", borderRadius: 6, color: "#fff", padding: 4, fontSize: 12, width: 50 },
  smallSaveBtn: { backgroundColor: "#4285F4", borderRadius: 4, paddingHorizontal: 8, paddingVertical: 3 },
  emptyText: { fontSize: 12, color: "#555", textAlign: "center", paddingVertical: 8 },
});
