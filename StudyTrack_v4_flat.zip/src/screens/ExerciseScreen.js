import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet,
} from "react-native";
import { DAY_NAMES, todayKey, monthKey, DEFAULT_EXERCISES } from "../utils/constants";

export default function ExerciseScreen() {
  const [exercisePlan, setExercisePlan] = useState(DEFAULT_EXERCISES);
  const [exDone, setExDone] = useState({ date: todayKey(), done: {} });
  const [exTab, setExTab] = useState("today");
  const [editingExDay, setEditingExDay] = useState(null);
  const [editingEx, setEditingEx] = useState(null);
  const [editExVal, setEditExVal] = useState({ name: "", sets: "" });
  const [addingEx, setAddingEx] = useState(null);
  const [newEx, setNewEx] = useState({ name: "", sets: "" });
  const [exMonthLog, setExMonthLog] = useState({});

  const todayName = DAY_NAMES[new Date().getDay()];

  // Reset after 24h
  if (exDone.date !== todayKey()) {
    setExDone({ date: todayKey(), done: {} });
  }

  const toggleEx = (day, id) => {
    const mk = monthKey();
    setExDone((p) => {
      const nd = { ...p.done };
      if (!nd[day]) nd[day] = {};
      nd[day] = { ...nd[day], [id]: !nd[day][id] };
      return { date: p.date, done: nd };
    });
    setExMonthLog((p) => {
      const mo = p[mk] || {};
      const dayLog = mo[day] || 0;
      const prev = exDone.done[day]?.[id];
      return { ...p, [mk]: { ...mo, [day]: prev ? Math.max(0, dayLog - 1) : dayLog + 1 } };
    });
  };

  const saveEditEx = (day) => {
    setExercisePlan((p) => ({
      ...p,
      [day]: { ...p[day], exercises: p[day].exercises.map((e) => (e.id === editingEx.id ? { ...e, ...editExVal } : e)) },
    }));
    setEditingEx(null);
  };

  const deleteEx = (day, id) =>
    setExercisePlan((p) => ({
      ...p,
      [day]: { ...p[day], exercises: p[day].exercises.filter((e) => e.id !== id) },
    }));

  const addExercise = (day) => {
    if (!newEx.name.trim()) return;
    const exs = exercisePlan[day].exercises;
    const newId = exs.length > 0 ? Math.max(...exs.map((e) => e.id)) + 1 : 1;
    setExercisePlan((p) => ({
      ...p,
      [day]: { ...p[day], exercises: [...p[day].exercises, { id: newId, ...newEx }] },
    }));
    setNewEx({ name: "", sets: "" });
    setAddingEx(null);
  };

  const mk = monthKey();
  const exMonthData = Object.entries(exercisePlan).map(([day, plan]) => {
    const total = plan.exercises.length;
    const done = exMonthLog[mk]?.[day] || 0;
    return { day, total, done, pct: total > 0 ? Math.round((Math.min(done, total) / total) * 100) : 0 };
  });

  const dayName = editingExDay || todayName;
  const dayPlan = exercisePlan[dayName];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Sub-tabs */}
      <View style={styles.subTabRow}>
        {[
          { id: "today", label: "Today's Plan" },
          { id: "monthly", label: "Monthly Progress" },
        ].map((t) => (
          <TouchableOpacity
            key={t.id}
            onPress={() => setExTab(t.id)}
            style={[styles.subTab, exTab === t.id && styles.subTabActive]}
          >
            <Text style={[styles.subTabText, exTab === t.id && styles.subTabTextActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {exTab === "today" && (
        <View>
          <View style={styles.card}>
            <View style={styles.rowBetween}>
              <View>
                <Text style={styles.dayTitle}>{dayName}</Text>
                <Text style={styles.dayLabel}>{exercisePlan[dayName].label}</Text>
              </View>
              <Text style={styles.doneCount}>
                {Object.values(exDone.done[dayName] || {}).filter(Boolean).length}/
                {exercisePlan[dayName].exercises.length} done
              </Text>
            </View>

            <View style={styles.progressBg}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: ((Object.values(exDone.done[dayName] || {}).filter(Boolean).length /
                      exercisePlan[dayName].exercises.length) * 100) + "%",
                    backgroundColor: "#34A853",
                  },
                ]}
              />
            </View>

            {dayPlan.exercises.map((ex) => {
              const done = !!(exDone.done[dayName]?.[ex.id]);
              const isEdit = editingEx && editingEx.day === dayName && editingEx.id === ex.id;
              return (
                <View key={ex.id} style={styles.exRow}>
                  <TouchableOpacity
                    onPress={() => toggleEx(dayName, ex.id)}
                    style={[styles.checkbox, done && styles.checkboxDone]}
                  >
                    {done && <Text style={{ color: "#fff", fontSize: 11 }}>✓</Text>}
                  </TouchableOpacity>
                  {isEdit ? (
                    <View style={{ flex: 1 }}>
                      <TextInput
                        value={editExVal.name}
                        onChangeText={(v) => setEditExVal((p) => ({ ...p, name: v }))}
                        style={[styles.input, { marginBottom: 4, fontSize: 12 }]}
                      />
                      <TextInput
                        value={editExVal.sets}
                        onChangeText={(v) => setEditExVal((p) => ({ ...p, sets: v }))}
                        style={[styles.input, { marginBottom: 4, fontSize: 12 }]}
                      />
                      <View style={styles.row}>
                        <TouchableOpacity onPress={() => saveEditEx(dayName)} style={[styles.smallBtn, { backgroundColor: "#4285F4" }]}>
                          <Text style={{ color: "#fff", fontSize: 12 }}>Save</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => setEditingEx(null)} style={styles.smallGhost}>
                          <Text style={{ color: "#aaa", fontSize: 12 }}>Cancel</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  ) : (
                    <>
                      <View style={{ flex: 1 }}>
                        <Text style={[styles.exName, done && styles.exDone]}>{ex.name}</Text>
                        <Text style={styles.exSets}>{ex.sets}</Text>
                      </View>
                      <TouchableOpacity onPress={() => { setEditingEx({ day: dayName, id: ex.id }); setEditExVal({ name: ex.name, sets: ex.sets }); }}>
                        <Text style={styles.iconBtn}>Edit</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => deleteEx(dayName, ex.id)}>
                        <Text style={[styles.iconBtn, { color: "#EA4335" }]}>Del</Text>
                      </TouchableOpacity>
                    </>
                  )}
                </View>
              );
            })}

            {addingEx === dayName ? (
              <View style={{ marginTop: 10 }}>
                <TextInput
                  placeholder="Exercise name"
                  value={newEx.name}
                  onChangeText={(v) => setNewEx((p) => ({ ...p, name: v }))}
                  placeholderTextColor="#555"
                  style={styles.input}
                />
                <TextInput
                  placeholder="Sets/reps"
                  value={newEx.sets}
                  onChangeText={(v) => setNewEx((p) => ({ ...p, sets: v }))}
                  placeholderTextColor="#555"
                  style={styles.input}
                />
                <View style={styles.row}>
                  <TouchableOpacity onPress={() => addExercise(dayName)} style={[styles.smallBtn, { backgroundColor: "#34A853" }]}>
                    <Text style={{ color: "#fff", fontSize: 12 }}>Add</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => setAddingEx(null)} style={styles.smallGhost}>
                    <Text style={{ color: "#aaa", fontSize: 12 }}>Cancel</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <TouchableOpacity onPress={() => setAddingEx(dayName)} style={styles.addExBtn}>
                <Text style={styles.addExBtnText}>+ Add Exercise</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Day selector */}
          <View style={styles.card}>
            <Text style={styles.sectionLabel}>ALAG DIN DEKHNA HO TOH</Text>
            <View style={styles.dayRow}>
              {DAY_NAMES.map((d) => {
                const isActive = editingExDay === d || (d === todayName && !editingExDay);
                return (
                  <TouchableOpacity
                    key={d}
                    onPress={() => setEditingExDay(editingExDay === d ? null : d)}
                    style={[styles.dayBtn, isActive && styles.dayBtnActive]}
                  >
                    <Text style={[styles.dayBtnText, isActive && styles.dayBtnTextActive]}>
                      {d.slice(0, 3)}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          <Text style={styles.hint}>Exercise ticks auto-reset every 24h</Text>
        </View>
      )}

      {exTab === "monthly" && (
        <View style={styles.card}>
          <Text style={styles.sectionLabel}>
            {new Date().toLocaleString("en-IN", { month: "long", year: "numeric" })}
          </Text>
          {exMonthData.map(({ day, total, done, pct }) => (
            <View key={day} style={{ marginBottom: 11 }}>
              <View style={styles.rowBetween}>
                <Text style={styles.dayName}>{day}</Text>
                <Text style={styles.hint}>{Math.min(done, total)}/{total} exercises · {pct}%</Text>
              </View>
              <View style={styles.progressBg}>
                <View style={[styles.progressFill, {
                  width: pct + "%",
                  backgroundColor: pct >= 80 ? "#34A853" : pct >= 40 ? "#FBBC04" : "#EA4335",
                }]} />
              </View>
            </View>
          ))}
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  subTabRow: { flexDirection: "row", backgroundColor: "#1a1a1a", borderRadius: 10, padding: 4, marginBottom: 16, gap: 4 },
  subTab: { flex: 1, paddingVertical: 8, borderRadius: 7, alignItems: "center" },
  subTabActive: { backgroundColor: "#252525" },
  subTabText: { color: "#666", fontWeight: "600", fontSize: 12 },
  subTabTextActive: { color: "#fff" },
  card: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 12, padding: 14, marginBottom: 14 },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  row: { flexDirection: "row", gap: 8, alignItems: "center" },
  dayTitle: { fontWeight: "700", fontSize: 15, color: "#34A853" },
  dayLabel: { fontSize: 11, color: "#888", marginTop: 2 },
  doneCount: { fontSize: 11, color: "#888" },
  progressBg: { backgroundColor: "#252525", borderRadius: 5, height: 5, overflow: "hidden", marginBottom: 14 },
  progressFill: { height: "100%", borderRadius: 5 },
  exRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#1e1e1e" },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: "#333", backgroundColor: "transparent", alignItems: "center", justifyContent: "center" },
  checkboxDone: { borderColor: "#34A853", backgroundColor: "#34A853" },
  exName: { fontSize: 13, color: "#ddd" },
  exDone: { color: "#555", textDecorationLine: "line-through" },
  exSets: { fontSize: 11, color: "#666" },
  iconBtn: { color: "#555", fontSize: 11, paddingHorizontal: 4 },
  input: { backgroundColor: "#111", borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, color: "#fff", padding: 8, fontSize: 13, marginBottom: 6 },
  smallBtn: { borderRadius: 6, paddingHorizontal: 12, paddingVertical: 5 },
  smallGhost: { borderWidth: 1, borderColor: "#333", borderRadius: 6, paddingHorizontal: 10, paddingVertical: 5 },
  addExBtn: { marginTop: 10, borderWidth: 1, borderColor: "#2a2a2a", borderStyle: "dashed", borderRadius: 8, paddingVertical: 7, alignItems: "center" },
  addExBtnText: { color: "#555", fontSize: 12 },
  sectionLabel: { fontSize: 11, color: "#888", fontWeight: "600", letterSpacing: 1, marginBottom: 10 },
  dayRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  dayBtn: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, borderWidth: 1.5, borderColor: "#2a2a2a" },
  dayBtnActive: { borderColor: "#34A853", backgroundColor: "#34A85322" },
  dayBtnText: { color: "#777", fontSize: 11, fontWeight: "600" },
  dayBtnTextActive: { color: "#34A853" },
  hint: { fontSize: 10, color: "#444" },
  dayName: { fontSize: 13, fontWeight: "600", color: "#ccc" },
});
