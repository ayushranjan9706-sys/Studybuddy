import React, { useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { BLOCK_TYPES, SUB_COLORS, fmt, todayKey, monthKey } from "../utils/constants";

export default function ProgressScreen({ tests, setTests, subjects, sessions, exMonthData }) {
  const [progressTab, setProgressTab] = useState("study");

  const getTestProgress = (t) => {
    const total = t.subjects.reduce((a, s) => a + s.chapters.length * BLOCK_TYPES.length, 0);
    const done = t.subjects.reduce((a, s) => a + s.chapters.reduce((b, c) => b + BLOCK_TYPES.filter((bl) => c.blocks[bl]).length, 0), 0);
    return { total, done, pct: total > 0 ? Math.round((done / total) * 100) : 0 };
  };

  const monthSessions = sessions.filter((s) => s.date && s.date.startsWith(new Date().getFullYear() + "-"));

  const habitItems = [
    "Sleep 6-8 hours",
    "Avoid stomach sleeping",
    "Stand every 40-50 min while studying",
    "Drink 2.5-3L water daily",
    "Reduce sugary drinks",
    "Walk after meals 5-10 min",
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Sub-tabs */}
      <View style={styles.subTabRow}>
        {[
          { id: "study", label: "Study Progress" },
          { id: "exercise", label: "Exercise Progress" },
        ].map((t) => (
          <TouchableOpacity
            key={t.id}
            onPress={() => setProgressTab(t.id)}
            style={[styles.subTab, progressTab === t.id && styles.subTabActive]}
          >
            <Text style={[styles.subTabText, progressTab === t.id && styles.subTabTextActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {progressTab === "study" && (
        <View>
          <Text style={styles.sectionLabel}>TESTS KA TARGET vs PROGRESS</Text>
          {tests.length === 0 && <Text style={styles.emptyText}>Koi test nahi hai abhi.</Text>}

          {tests.map((t, i) => {
            const { total, done, pct } = getTestProgress(t);
            return (
              <View key={t.id} style={styles.card}>
                <View style={styles.rowBetween}>
                  <View>
                    <Text style={styles.testName}>{t.name}</Text>
                    <Text style={styles.testDate}>
                      {t.date ? new Date(t.date + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : ""}
                    </Text>
                  </View>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={[styles.pctBig, pct >= 100 && { color: "#34A853" }]}>{pct}%</Text>
                    <Text style={styles.blockCount}>{done}/{total} blocks</Text>
                  </View>
                </View>

                <View style={styles.progressBg}>
                  <View style={[styles.progressFill, {
                    width: pct + "%",
                    backgroundColor: pct >= 100 ? "#34A853" : "#EA4335",
                  }]} />
                </View>

                {t.subjects.map((s, si) => {
                  const tb = s.chapters.length * BLOCK_TYPES.length;
                  const db = s.chapters.reduce((a, c) => a + BLOCK_TYPES.filter((b) => c.blocks[b]).length, 0);
                  const sp = tb > 0 ? Math.round((db / tb) * 100) : 0;
                  return (
                    <View key={si} style={styles.subjRow}>
                      <View style={[styles.dot, { backgroundColor: SUB_COLORS[si % SUB_COLORS.length] }]} />
                      <Text style={styles.subjName}>{s.name}</Text>
                      <View style={styles.miniProgressBg}>
                        <View style={[styles.miniProgressFill, { width: sp + "%", backgroundColor: SUB_COLORS[si % SUB_COLORS.length] }]} />
                      </View>
                      <Text style={styles.miniPct}>{sp}%</Text>
                    </View>
                  );
                })}

                <TouchableOpacity
                  onPress={() => setTests((p) => p.map((tt, ii) =>
                    ii === i
                      ? { ...tt, subjects: tt.subjects.map((s) => ({ ...s, chapters: s.chapters.map((c) => ({ ...c, blocks: {} })) })), resetDate: todayKey() }
                      : tt
                  ))}
                  style={styles.resetBtn}
                >
                  <Text style={styles.resetBtnText}>Test ke baad reset karo</Text>
                </TouchableOpacity>
              </View>
            );
          })}

          {/* Study time stats */}
          <View style={styles.card}>
            <Text style={styles.sectionLabel}>STUDY SESSIONS THIS MONTH</Text>
            {monthSessions.length === 0 && <Text style={styles.emptyText}>Koi session nahi abhi.</Text>}
            {subjects.map((s) => {
              const secs = monthSessions.filter((x) => x.subject === s.name).reduce((a, x) => a + x.duration, 0);
              const total = monthSessions.reduce((a, x) => a + x.duration, 0);
              const pct = total > 0 ? Math.round((secs / total) * 100) : 0;
              if (!secs) return null;
              return (
                <View key={s.name} style={{ marginBottom: 10 }}>
                  <View style={styles.rowBetween}>
                    <Text style={[styles.subjNameBig, { color: s.color }]}>{s.name}</Text>
                    <Text style={styles.hint}>{fmt(secs)} · {pct}%</Text>
                  </View>
                  <View style={styles.progressBg}>
                    <View style={[styles.progressFill, { width: pct + "%", backgroundColor: s.color }]} />
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      )}

      {progressTab === "exercise" && (
        <View>
          <Text style={styles.sectionLabel}>MONTHLY EXERCISE PROGRESS</Text>
          <View style={styles.card}>
            <Text style={[styles.hint, { marginBottom: 12 }]}>
              {new Date().toLocaleString("en-IN", { month: "long", year: "numeric" })}
            </Text>
            {(exMonthData || []).map(({ day, total, done, pct }) => (
              <View key={day} style={{ marginBottom: 11 }}>
                <View style={styles.rowBetween}>
                  <Text style={styles.dayName}>{day}</Text>
                  <Text style={styles.hint}>{pct}%</Text>
                </View>
                <View style={styles.progressBg}>
                  <View style={[styles.progressFill, {
                    width: pct + "%",
                    backgroundColor: pct >= 80 ? "#34A853" : pct >= 40 ? "#FBBC04" : "#EA4335",
                  }]} />
                </View>
              </View>
            ))}
          </View>

          <View style={styles.card}>
            <Text style={styles.sectionLabel}>DAILY HABITS</Text>
            {habitItems.map((h, i) => (
              <View key={i} style={styles.habitRow}>
                <Text style={styles.habitText}>{h}</Text>
              </View>
            ))}
          </View>
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  subTabRow: { flexDirection: "row", backgroundColor: "#1a1a1a", borderRadius: 10, padding: 4, marginBottom: 16, gap: 4 },
  subTab: { flex: 1, paddingVertical: 8, borderRadius: 7, alignItems: "center" },
  subTabActive: { backgroundColor: "#252525" },
  subTabText: { color: "#666", fontWeight: "600", fontSize: 12 },
  subTabTextActive: { color: "#fff" },
  sectionLabel: { fontSize: 11, color: "#888", fontWeight: "600", letterSpacing: 1, marginBottom: 12 },
  emptyText: { textAlign: "center", color: "#555", fontSize: 14, marginTop: 30 },
  card: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 12, padding: 14, marginBottom: 12 },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 7 },
  testName: { fontWeight: "700", fontSize: 14, color: "#EA4335" },
  testDate: { fontSize: 11, color: "#888", marginTop: 2 },
  pctBig: { fontSize: 22, fontWeight: "800", color: "#4285F4" },
  blockCount: { fontSize: 11, color: "#888" },
  progressBg: { backgroundColor: "#252525", borderRadius: 8, height: 8, overflow: "hidden", marginBottom: 10 },
  progressFill: { height: "100%", borderRadius: 8 },
  subjRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 6 },
  dot: { width: 7, height: 7, borderRadius: 4, flexShrink: 0 },
  subjName: { fontSize: 12, flex: 1, color: "#ccc" },
  miniProgressBg: { backgroundColor: "#252525", borderRadius: 4, height: 4, width: 80, overflow: "hidden" },
  miniProgressFill: { height: "100%", borderRadius: 4 },
  miniPct: { fontSize: 11, color: "#888", minWidth: 30, textAlign: "right" },
  resetBtn: { marginTop: 10, borderWidth: 1, borderColor: "#333", borderRadius: 7, paddingVertical: 6, alignItems: "center" },
  resetBtnText: { color: "#EA4335", fontSize: 11 },
  subjNameBig: { fontSize: 13, fontWeight: "600" },
  hint: { fontSize: 10, color: "#444" },
  dayName: { fontSize: 13, fontWeight: "600", color: "#ccc" },
  habitRow: { paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: "#1e1e1e" },
  habitText: { fontSize: 12, color: "#aaa" },
});
