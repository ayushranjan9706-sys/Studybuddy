import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet,
} from "react-native";
import { BLOCK_TYPES, BLOCK_COLORS, SUB_COLORS } from "../utils/constants";

export default function SubjectsScreen({ subjects, setSubjects }) {
  // "11th" or "12th"
  const [classTab, setClassTab] = useState("11th");
  const [activeSubIdx, setActiveSubIdx] = useState(null);
  const [newSubName, setNewSubName] = useState("");
  const [addingSub, setAddingSub] = useState(false);
  const [newChapName, setNewChapName] = useState("");
  const [editingChap, setEditingChap] = useState(null);
  const [editChapVal, setEditChapVal] = useState("");

  // Filter subjects by class
  const filteredSubjects = subjects
    .map((s, i) => ({ ...s, originalIndex: i }))
    .filter((s) => s.class === classTab);

  // When switching class tab, reset active sub
  const handleClassTab = (tab) => {
    setClassTab(tab);
    setActiveSubIdx(null);
    setAddingSub(false);
  };

  const addSubject = () => {
    if (!newSubName.trim()) return;
    const allColors = SUB_COLORS;
    const usedCount = subjects.filter((s) => s.class === classTab).length;
    setSubjects((p) => [
      ...p,
      {
        name: newSubName.trim(),
        color: allColors[usedCount % allColors.length],
        chapters: [],
        class: classTab,
      },
    ]);
    setNewSubName(""); setAddingSub(false);
    setActiveSubIdx(subjects.length); // will point to the new item
  };

  const addChapter = (originalIdx) => {
    if (!newChapName.trim()) return;
    setSubjects((p) =>
      p.map((s, i) =>
        i === originalIdx
          ? { ...s, chapters: [...s.chapters, { name: newChapName.trim(), blocks: {} }] }
          : s
      )
    );
    setNewChapName("");
  };

  const saveEditChap = (originalIdx) => {
    if (!editChapVal.trim()) return;
    const { ci } = editingChap;
    setSubjects((p) =>
      p.map((s, i) =>
        i === originalIdx
          ? { ...s, chapters: s.chapters.map((c, j) => (j === ci ? { ...c, name: editChapVal } : c)) }
          : s
      )
    );
    setEditingChap(null);
  };

  const toggleBlock = (originalIdx, ci, b) =>
    setSubjects((p) =>
      p.map((s, i) =>
        i === originalIdx
          ? { ...s, chapters: s.chapters.map((c, j) => (j === ci ? { ...c, blocks: { ...c.blocks, [b]: !c.blocks[b] } } : c)) }
          : s
      )
    );

  const deleteChapter = (originalIdx, ci) =>
    setSubjects((p) =>
      p.map((s, i) =>
        i === originalIdx
          ? { ...s, chapters: s.chapters.filter((_, j) => j !== ci) }
          : s
      )
    );

  const renameSubject = (originalIdx, val) =>
    setSubjects((p) => p.map((s, i) => (i === originalIdx ? { ...s, name: val } : s)));

  const deleteSubject = (originalIdx) => {
    setSubjects((p) => p.filter((_, i) => i !== originalIdx));
    setActiveSubIdx(null);
  };

  // Get active subject using originalIndex
  const activeSubject = activeSubIdx !== null
    ? filteredSubjects.find((s) => s.originalIndex === activeSubIdx)
    : null;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* 11th / 12th Tab */}
      <View style={styles.classTabRow}>
        {["11th", "12th"].map((t) => (
          <TouchableOpacity
            key={t}
            onPress={() => handleClassTab(t)}
            style={[styles.classTab, classTab === t && styles.classTabActive]}
          >
            <Text style={[styles.classTabText, classTab === t && styles.classTabTextActive]}>
              {t}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Subject pills */}
      <View style={styles.pillRow}>
        {filteredSubjects.map((s) => (
          <TouchableOpacity
            key={s.originalIndex}
            onPress={() => setActiveSubIdx(s.originalIndex)}
            style={[
              styles.pill,
              activeSubIdx === s.originalIndex && { borderColor: s.color, backgroundColor: s.color + "22" },
            ]}
          >
            <Text style={[styles.pillText, activeSubIdx === s.originalIndex && { color: s.color }]}>
              {s.name}
            </Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={() => setAddingSub(true)} style={styles.pillAdd}>
          <Text style={styles.pillAddText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {/* Add subject form */}
      {addingSub && (
        <View style={styles.card}>
          <View style={styles.row}>
            <TextInput
              autoFocus
              value={newSubName}
              onChangeText={setNewSubName}
              onSubmitEditing={addSubject}
              placeholder={`${classTab} subject name`}
              placeholderTextColor="#555"
              style={[styles.input, { flex: 1, marginBottom: 0, marginRight: 8 }]}
            />
            <TouchableOpacity onPress={addSubject} style={styles.btnPrimary}>
              <Text style={styles.btnPrimaryText}>Add</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setAddingSub(false)} style={styles.btnGhost}>
              <Text style={styles.btnGhostText}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Active subject detail */}
      {activeSubject && (
        <View>
          {/* Subject name + class badge */}
          <View style={styles.subjectHeader}>
            <View style={[styles.dot, { backgroundColor: activeSubject.color }]} />
            <TextInput
              value={activeSubject.name}
              onChangeText={(val) => renameSubject(activeSubject.originalIndex, val)}
              style={[styles.subjectName, { color: activeSubject.color }]}
            />
            <View style={styles.classBadge}>
              <Text style={styles.classBadgeText}>{activeSubject.class}</Text>
            </View>
            <Text style={styles.chapCount}>{activeSubject.chapters.length} ch</Text>
            <TouchableOpacity onPress={() => deleteSubject(activeSubject.originalIndex)}>
              <Text style={{ color: "#555", fontSize: 13 }}>Delete</Text>
            </TouchableOpacity>
          </View>

          {/* Add chapter */}
          <View style={styles.row}>
            <TextInput
              value={newChapName}
              onChangeText={setNewChapName}
              onSubmitEditing={() => addChapter(activeSubject.originalIndex)}
              placeholder="+ Chapter name"
              placeholderTextColor="#555"
              style={[styles.input, { flex: 1, marginBottom: 0, marginRight: 8 }]}
            />
            <TouchableOpacity
              onPress={() => addChapter(activeSubject.originalIndex)}
              style={[styles.btnPrimary, { backgroundColor: activeSubject.color }]}
            >
              <Text style={styles.btnPrimaryText}>Add</Text>
            </TouchableOpacity>
          </View>

          {activeSubject.chapters.length === 0 && (
            <Text style={styles.emptyText}>No chapters yet</Text>
          )}

          {activeSubject.chapters.map((ch, ci) => {
            const dc = BLOCK_TYPES.filter((b) => ch.blocks[b]).length;
            const isEditing = editingChap && editingChap.ci === ci && editingChap.oi === activeSubject.originalIndex;
            return (
              <View key={ci} style={styles.chapCard}>
                <View style={styles.chapHeader}>
                  {isEditing ? (
                    <View style={[styles.row, { flex: 1 }]}>
                      <TextInput
                        autoFocus
                        value={editChapVal}
                        onChangeText={setEditChapVal}
                        onSubmitEditing={() => saveEditChap(activeSubject.originalIndex)}
                        style={[styles.input, { flex: 1, marginBottom: 0, marginRight: 6, fontSize: 13, paddingVertical: 4 }]}
                      />
                      <TouchableOpacity onPress={() => saveEditChap(activeSubject.originalIndex)} style={[styles.btnPrimary, { paddingHorizontal: 10, paddingVertical: 4 }]}>
                        <Text style={styles.btnPrimaryText}>OK</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => setEditingChap(null)} style={[styles.btnGhost, { paddingHorizontal: 8, paddingVertical: 4, marginLeft: 6 }]}>
                        <Text style={styles.btnGhostText}>✕</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <Text style={styles.chapName}>{ch.name}</Text>
                  )}
                  <View style={styles.chapActions}>
                    <Text style={styles.chapCount2}>{dc}/{BLOCK_TYPES.length}</Text>
                    {!isEditing && (
                      <TouchableOpacity onPress={() => { setEditingChap({ oi: activeSubject.originalIndex, ci }); setEditChapVal(ch.name); }}>
                        <Text style={styles.iconBtn}>Edit</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity onPress={() => deleteChapter(activeSubject.originalIndex, ci)}>
                      <Text style={[styles.iconBtn, { color: "#EA4335" }]}>Del</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                {/* Progress bar */}
                <View style={styles.progressBg}>
                  <View style={[styles.progressFill, { width: (dc / BLOCK_TYPES.length * 100) + "%", backgroundColor: activeSubject.color }]} />
                </View>

                {/* Block buttons */}
                <View style={styles.blockRow}>
                  {BLOCK_TYPES.map((b) => {
                    const done = !!ch.blocks[b];
                    return (
                      <TouchableOpacity
                        key={b}
                        onPress={() => toggleBlock(activeSubject.originalIndex, ci, b)}
                        style={[
                          styles.blockBtn,
                          done && { borderColor: BLOCK_COLORS[b], backgroundColor: BLOCK_COLORS[b] + "33" },
                        ]}
                      >
                        <Text style={[styles.blockBtnText, done && { color: BLOCK_COLORS[b] }]}>
                          {done ? "✓ " : ""}{b}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            );
          })}
        </View>
      )}

      {filteredSubjects.length === 0 && !addingSub && (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>Koi {classTab} subject nahi.</Text>
          <TouchableOpacity onPress={() => setAddingSub(true)} style={styles.btnPrimary}>
            <Text style={styles.btnPrimaryText}>+ Subject Add Karo</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  classTabRow: {
    flexDirection: "row",
    backgroundColor: "#1a1a1a",
    borderRadius: 10,
    padding: 4,
    marginBottom: 14,
    gap: 4,
  },
  classTab: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 7,
    alignItems: "center",
  },
  classTabActive: { backgroundColor: "#252525" },
  classTabText: { color: "#666", fontWeight: "700", fontSize: 14 },
  classTabTextActive: { color: "#fff" },
  pillRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 14, alignItems: "center" },
  pill: { paddingHorizontal: 13, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, borderColor: "#2a2a2a" },
  pillText: { color: "#888", fontSize: 13, fontWeight: "600" },
  pillAdd: { paddingHorizontal: 13, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, borderColor: "#333", borderStyle: "dashed" },
  pillAddText: { color: "#555", fontSize: 13 },
  card: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 10, padding: 13, marginBottom: 14 },
  row: { flexDirection: "row", alignItems: "center", marginBottom: 13 },
  input: { backgroundColor: "#111", borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, color: "#fff", padding: 8, fontSize: 13 },
  btnPrimary: { backgroundColor: "#4285F4", borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  btnPrimaryText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  btnGhost: { borderWidth: 1, borderColor: "#2a2a2a", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, marginLeft: 8 },
  btnGhostText: { color: "#aaa", fontSize: 13 },
  subjectHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 13 },
  dot: { width: 9, height: 9, borderRadius: 5 },
  subjectName: { fontWeight: "700", fontSize: 15, flex: 1, borderBottomWidth: 1, borderBottomColor: "#252525", paddingBottom: 2 },
  classBadge: { backgroundColor: "#252525", borderRadius: 5, paddingHorizontal: 7, paddingVertical: 2 },
  classBadgeText: { color: "#aaa", fontSize: 10, fontWeight: "700" },
  chapCount: { fontSize: 11, color: "#555" },
  emptyText: { textAlign: "center", color: "#555", fontSize: 13, marginTop: 24 },
  chapCard: { backgroundColor: "#1a1a1a", borderWidth: 1, borderColor: "#252525", borderRadius: 10, padding: 12, marginBottom: 9 },
  chapHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  chapName: { fontWeight: "600", fontSize: 13, flex: 1, color: "#f0f0f0" },
  chapActions: { flexDirection: "row", alignItems: "center", gap: 8, flexShrink: 0 },
  chapCount2: { fontSize: 11, color: "#888" },
  iconBtn: { color: "#555", fontSize: 11 },
  progressBg: { backgroundColor: "#252525", borderRadius: 5, height: 4, marginBottom: 9, overflow: "hidden" },
  progressFill: { height: "100%" },
  blockRow: { flexDirection: "row", gap: 6, flexWrap: "wrap" },
  blockBtn: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 7, borderWidth: 1.5, borderColor: "#2a2a2a" },
  blockBtnText: { color: "#666", fontSize: 11, fontWeight: "600" },
  emptyState: { alignItems: "center", marginTop: 50 },
  emptyStateText: { color: "#555", fontSize: 14, marginBottom: 12 },
});
