import React, { useState, useEffect } from "react";
import {
  View, Text, TouchableOpacity, TextInput, StyleSheet,
} from "react-native";

export default function Countdown({ targetDate, label, onEdit }) {
  const [left, setLeft] = useState({});
  const [editing, setEditing] = useState(false);
  const [inp, setInp] = useState(targetDate);

  useEffect(() => {
    const calc = () => {
      const diff = new Date(targetDate) - new Date();
      if (diff <= 0) { setLeft({ done: true }); return; }
      setLeft({
        d: Math.floor(diff / 86400000),
        h: Math.floor((diff % 86400000) / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    };
    calc();
    const id = setInterval(calc, 1000);
    return () => clearInterval(id);
  }, [targetDate]);

  // Parse YYYY-MM-DD to display nicely
  const formatDate = (dateStr) => {
    try {
      const d = new Date(dateStr + "T00:00:00");
      return d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
    } catch { return dateStr; }
  };

  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <Text style={styles.label}>{label}</Text>
        {!editing && (
          <TouchableOpacity onPress={() => { setInp(targetDate); setEditing(true); }} style={styles.editBtn}>
            <Text style={styles.editBtnText}>Edit Date</Text>
          </TouchableOpacity>
        )}
      </View>

      {editing && (
        <View style={styles.editRow}>
          <Text style={styles.editHint}>Enter date (YYYY-MM-DD):</Text>
          <TextInput
            value={inp}
            onChangeText={setInp}
            placeholder="2027-05-03"
            placeholderTextColor="#555"
            style={styles.dateInput}
            keyboardType="numeric"
          />
          <View style={styles.editButtons}>
            <TouchableOpacity onPress={() => { onEdit(inp); setEditing(false); }} style={styles.saveBtn}>
              <Text style={styles.saveBtnText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setEditing(false)} style={styles.cancelBtn}>
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {left.done ? (
        <Text style={styles.doneText}>Time's up!</Text>
      ) : (
        <View style={styles.timerRow}>
          {[["d", "Days"], ["h", "Hrs"], ["m", "Min"], ["s", "Sec"]].map(([k, l]) => (
            <View key={k} style={styles.timerBox}>
              <Text style={styles.timerNum}>{String(left[k] ?? 0).padStart(2, "0")}</Text>
              <Text style={styles.timerLbl}>{l}</Text>
            </View>
          ))}
        </View>
      )}

      <Text style={styles.dateText}>{formatDate(targetDate)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#1a1a1a",
    borderWidth: 1,
    borderColor: "#252525",
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  label: { fontSize: 11, color: "#888", fontWeight: "600", letterSpacing: 1 },
  editBtn: {
    borderWidth: 1, borderColor: "#333", borderRadius: 6,
    paddingHorizontal: 9, paddingVertical: 3,
  },
  editBtnText: { color: "#aaa", fontSize: 11 },
  editHint: { color: "#888", fontSize: 11, marginBottom: 6 },
  editRow: { marginBottom: 10 },
  dateInput: {
    backgroundColor: "#252525", borderWidth: 1, borderColor: "#333",
    borderRadius: 8, color: "#fff", padding: 8, fontSize: 14, marginBottom: 8,
  },
  editButtons: { flexDirection: "row", gap: 8 },
  saveBtn: {
    backgroundColor: "#4285F4", borderRadius: 6,
    paddingHorizontal: 14, paddingVertical: 6,
  },
  saveBtnText: { color: "#fff", fontSize: 12, fontWeight: "600" },
  cancelBtn: {
    borderWidth: 1, borderColor: "#333", borderRadius: 6,
    paddingHorizontal: 10, paddingVertical: 6,
  },
  cancelBtnText: { color: "#aaa", fontSize: 12 },
  doneText: { textAlign: "center", color: "#EA4335", fontWeight: "700", fontSize: 16 },
  timerRow: { flexDirection: "row", gap: 6, justifyContent: "center" },
  timerBox: {
    flex: 1, backgroundColor: "#111", borderWidth: 1, borderColor: "#2a2a2a",
    borderRadius: 9, paddingVertical: 9, paddingHorizontal: 4, alignItems: "center",
  },
  timerNum: { fontSize: 24, fontWeight: "800", color: "#4285F4" },
  timerLbl: { fontSize: 10, color: "#555" },
  dateText: { textAlign: "center", marginTop: 7, fontSize: 11, color: "#555" },
});
