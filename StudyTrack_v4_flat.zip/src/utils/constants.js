// ─── Constants ───────────────────────────────────────
export const BLOCK_TYPES = ["Notes", "Lectures", "Test", "PYQ", "Module"];
export const BLOCK_COLORS = {
  Notes: "#4285F4",
  Lectures: "#34A853",
  Test: "#EA4335",
  PYQ: "#FBBC04",
  Module: "#9C27B0",
};
export const SUB_COLORS = [
  "#4285F4","#34A853","#EA4335","#FBBC04",
  "#9C27B0","#FF6D00","#00BCD4","#E91E63",
];
export const DAY_NAMES = [
  "Sunday","Monday","Tuesday","Wednesday",
  "Thursday","Friday","Saturday",
];

export const todayKey = () => new Date().toISOString().split("T")[0];
export const monthKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}`;
};
export const fmt = (s) => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sc = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sc).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(sc).padStart(2, "0")}`;
};

export const DEFAULT_EXERCISES = {
  Monday: {
    label: "Posture + Core (40-45 min)",
    exercises: [
      { id: 1, name: "Hip flexor stretch", sets: "2 x 30 sec each side" },
      { id: 2, name: "Hamstring stretch", sets: "2 x 30 sec each side" },
      { id: 3, name: "Chest stretch", sets: "2 x 30 sec" },
      { id: 4, name: "Glute bridge", sets: "3 x 15" },
      { id: 5, name: "Bird dog", sets: "3 x 10 each side" },
      { id: 6, name: "Plank", sets: "3 x 20-30 sec" },
      { id: 7, name: "Walking", sets: "10 min" },
    ],
  },
  Tuesday: {
    label: "Strength + Fat Loss (40-50 min)",
    exercises: [
      { id: 1, name: "Pushups", sets: "3 x 5-10" },
      { id: 2, name: "Squats", sets: "3 x 15" },
      { id: 3, name: "Walking lunges", sets: "2 x 10 each leg" },
      { id: 4, name: "Superman hold", sets: "3 x 20 sec" },
      { id: 5, name: "Fast walking/jogging", sets: "15-20 min" },
    ],
  },
  Wednesday: {
    label: "Full Body + Posture (45 min)",
    exercises: [
      { id: 1, name: "Glute bridge", sets: "3 x 15" },
      { id: 2, name: "Bird dog", sets: "3 x 10 each side" },
      { id: 3, name: "Dead bug", sets: "3 x 10 each side" },
      { id: 4, name: "Plank", sets: "3 x 30 sec" },
      { id: 5, name: "Pushups", sets: "3 x 5-10" },
      { id: 6, name: "Walking", sets: "10 min" },
    ],
  },
  Thursday: {
    label: "Mobility + Recovery (30-40 min)",
    exercises: [
      { id: 1, name: "Hip flexor stretch", sets: "2 x 40 sec" },
      { id: 2, name: "Hamstring stretch", sets: "2 x 40 sec" },
      { id: 3, name: "Chest stretch", sets: "2 x 30 sec" },
      { id: 4, name: "Cat-cow", sets: "20 reps" },
      { id: 5, name: "Light walking", sets: "20 min" },
    ],
  },
  Friday: {
    label: "Strength + Core (45 min)",
    exercises: [
      { id: 1, name: "Pushups", sets: "3 x 8-12" },
      { id: 2, name: "Squats", sets: "3 x 15" },
      { id: 3, name: "Walking lunges", sets: "2 x 10 each leg" },
      { id: 4, name: "Plank", sets: "3 x 30-45 sec" },
      { id: 5, name: "Dead bug", sets: "3 x 10 each side" },
      { id: 6, name: "Superman hold", sets: "3 x 20 sec" },
    ],
  },
  Saturday: {
    label: "Full Routine (50-60 min)",
    exercises: [
      { id: 1, name: "Hip flexor stretch", sets: "2 x 30 sec" },
      { id: 2, name: "Hamstring stretch", sets: "2 x 30 sec" },
      { id: 3, name: "Glute bridge", sets: "3 x 15" },
      { id: 4, name: "Bird dog", sets: "3 x 10 each side" },
      { id: 5, name: "Pushups", sets: "3 x 10" },
      { id: 6, name: "Squats", sets: "3 x 15" },
      { id: 7, name: "Plank", sets: "3 x 45 sec" },
      { id: 8, name: "Fast walking/jogging", sets: "20 min" },
    ],
  },
  Sunday: {
    label: "Active Recovery (20-30 min)",
    exercises: [
      { id: 1, name: "Light stretching", sets: "10 min" },
      { id: 2, name: "Walking", sets: "20 min" },
    ],
  },
};
