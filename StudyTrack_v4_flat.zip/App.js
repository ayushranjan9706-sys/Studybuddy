import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar,
} from "react-native";
import TimerScreen from "./src/screens/TimerScreen";
import SubjectsScreen from "./src/screens/SubjectsScreen";
import TestsScreen from "./src/screens/TestsScreen";
import ExerciseScreen from "./src/screens/ExerciseScreen";
import ProgressScreen from "./src/screens/ProgressScreen";
import { DEFAULT_EXERCISES, monthKey } from "./src/utils/constants";

const TABS = [
  { id: "timer",    label: "Timer" },
  { id: "subjects", label: "Subjects" },
  { id: "tests",    label: "Tests" },
  { id: "exercise", label: "Exercise" },
  { id: "progress", label: "Progress" },
];

export default function App() {
  const [tab, setTab] = useState("timer");
  const [subjects, setSubjects] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [tests, setTests] = useState([]);

  // Exercise month log — shared for ProgressScreen
  const [exMonthLog, setExMonthLog] = useState({});
  const [exercisePlan] = useState(DEFAULT_EXERCISES);
  const mk = monthKey();
  const exMonthData = Object.entries(exercisePlan).map(([day, plan]) => {
    const total = plan.exercises.length;
    const done = exMonthLog[mk]?.[day] || 0;
    return { day, total, done, pct: total > 0 ? Math.round((Math.min(done, total) / total) * 100) : 0 };
  });

  const renderScreen = () => {
    switch (tab) {
      case "timer":
        return <TimerScreen subjects={subjects} sessions={sessions} setSessions={setSessions} />;
      case "subjects":
        return <SubjectsScreen subjects={subjects} setSubjects={setSubjects} />;
      case "tests":
        return <TestsScreen tests={tests} setTests={setTests} />;
      case "exercise":
        return <ExerciseScreen />;
      case "progress":
        return (
          <ProgressScreen
            tests={tests}
            setTests={setTests}
            subjects={subjects}
            sessions={sessions}
            exMonthData={exMonthData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#141414" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.appTitle}>StudyTrack</Text>
        </View>

        {/* Tab bar */}
        <View style={styles.tabBar}>
          {TABS.map((t) => (
            <TouchableOpacity
              key={t.id}
              onPress={() => setTab(t.id)}
              style={styles.tabItem}
            >
              <Text style={[styles.tabLabel, tab === t.id && styles.tabLabelActive]}>
                {t.label}
              </Text>
              {tab === t.id && <View style={styles.tabUnderline} />}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Screen content */}
      <View style={styles.content}>
        {renderScreen()}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#0f0f0f",
  },
  header: {
    backgroundColor: "#141414",
    borderBottomWidth: 1,
    borderBottomColor: "#1e1e1e",
    paddingTop: 8,
  },
  headerTop: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  appTitle: {
    fontWeight: "700",
    fontSize: 17,
    color: "#f0f0f0",
  },
  tabBar: {
    flexDirection: "row",
  },
  tabItem: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    position: "relative",
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: "600",
    color: "#555",
    textAlign: "center",
  },
  tabLabelActive: {
    color: "#ffffff",
  },
  tabUnderline: {
    position: "absolute",
    bottom: 0,
    left: "10%",
    right: "10%",
    height: 2,
    backgroundColor: "#4285F4",
    borderRadius: 2,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor: "#0f0f0f",
  },
});
